﻿
using System.Security.Cryptography.X509Certificates;

// Class to represent a recipe
class Recipe
{
    double ogScaleAmount = 1.0;
    string[] ingredient_Name;
    double[] ingredient_Amount;
    string[] ingredient_Measurement;
    string[] steps;

    //Constructor to initialize arrays for ingredients and steps
    public Recipe()
    {
        //Initialize arrays based on user input
        ingredient_Name = new string[0];
        ingredient_Amount = new double[0];
        ingredient_Measurement = new string[0];
        steps = new string[0];
    }

    //Method to write the details of the recipe
    public void recipeDetails()
    {
        Console.Write(" The number of ingredients: ");
        int ingredient_No = Convert.ToInt32(Console.ReadLine());

        //Declaring the values for the array
        ingredient_Name = new string[ingredient_No];
        ingredient_Amount = new double[ingredient_No];
        ingredient_Measurement = new string[ingredient_No];


        if (ingredient_Name.Length > 0)
        {
            if (ingredient_No > 0)
            {
                //Loop to input ingredient details
                for (int i = 0; i < ingredient_No; i++)
                {
                    Console.WriteLine();
                    Console.Write(" The name of ingredient " + (i + 1) + ": ");
                    ingredient_Name[i] = Console.ReadLine();

                    Console.Write(" The quantity: '");
                    ingredient_Amount[i] = Convert.ToDouble(Console.ReadLine());

                    Console.Write(" The unit of measurement: '");
                    ingredient_Measurement[i] = Console.ReadLine();

                }

                Console.WriteLine();
                Console.Write(" The number of steps for the user to follow: ");
                int steps_No = Convert.ToInt32(Console.ReadLine());

                //Initialize array for steps and input step descriptions
                steps = new string[steps_No];
                Console.WriteLine();
                Console.WriteLine(" Write a description for each step");
                Console.WriteLine();

                for (int s = 0; s < steps_No; s++)
                {
                    Console.Write(" Step " + (s + 1) + ": ");
                    steps[s] = Console.ReadLine();
                }
            }

        }
        else
        {
            Console.WriteLine(" There is already a recipe taken down. Clear the recipe to take down another one\n");
        }
    }

    //Method to display the ingredients of the recipe
    public void recipeDisplay()
    {
        //If the recipe is not empty, display the recipe
        if (ingredient_Name.Length > 0)
        {
            //Display ingredients
            Console.WriteLine(" Ingredients: ");
            for (int Ingredients = 0; Ingredients < ingredient_Name.Length; Ingredients++)
            {
                Console.WriteLine($" -{ingredient_Amount[Ingredients]} {ingredient_Measurement[Ingredients]} of {ingredient_Name[Ingredients]}\n");
            }

            //Display steps
            Console.WriteLine(" Steps: ");
            for (int s = 0; s < steps.Length; s++)
            {
                Console.WriteLine($" - {steps[s]}\n");
            }

        }
        //Else there is no recipe to display
        else
        {
            Console.WriteLine(" There is no recipe to display\n");
            return;
        }

    }
    //Method to change the scale of the recipe
    public void recipeScale(double scaleAmount)
    {
        //If the recipe is not empty, change the scale of the recipe
        if (ingredient_Name.Length > 0)
        {
            // Change scale of the recipe
            ogScaleAmount *= scaleAmount;
            for (int scale = 0; scale < ingredient_Amount.Length; scale++)
            {
                ingredient_Amount[scale] *= scaleAmount;
            }
        }
        //Else there is no recipe to scale
        else
        {
            Console.WriteLine(" There is no recipe to scale\n");
            return;
        }
    }

    //Method to reset the scale of the recipe
    public void recipeReset()
    {
        //If the recipe is not empty, reset the scale of the recipe
        if (ingredient_Name.Length > 0)
        {
            //Reset scale of the recipe
            for (int reset = 0; reset < ingredient_Amount.Length; reset++)
            {
                ingredient_Amount[reset] /= ogScaleAmount;
            }
            ogScaleAmount = 1.0;
        }
        //Else there is no recipe to clear
        else
        {
            Console.WriteLine(" There is no recipe to reset the scale of\n");
            return;
        }
    }

    //Method to clear the recipe
    public void recipeClear()
    {
        //If the recipe is not empty, clear the recipe
        if (ingredient_Name.Length > 0)
        {
            //Clears the recipe
            ingredient_Name = new string[0];
            ingredient_Amount = new double[0];
            ingredient_Measurement = new string[0];
            steps = new string[0];
        }
        //Else there is no recipe to clear
        else
        {
            Console.WriteLine(" There is no recipe to clear\n");
            return;
        }
    }

    // Class to run the program
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            // Main menu for recipe application
            Console.WriteLine(" Recipe Application \n");
            Console.WriteLine(" 1. Enter Recipe\n");
            Console.WriteLine(" 2. Display Recipe\n");
            Console.WriteLine(" 3. Change the scale of the recipe\n");
            Console.WriteLine(" 4. Reset the scale of the recipe\n");
            Console.WriteLine(" 5. Clear the recipe\n");
            Console.WriteLine(" 6. Close Application\n");

            //Loop to choose what you would like the application to do    
            while (true)
            {
                Console.Write(" Enter the value of what you would like to do: ");
                string choice = Console.ReadLine();
                Console.Write("\n");
                switch (choice)
                {
                    case "1":
                        recipe.recipeDetails();
                        break;

                    case "2":
                        recipe.recipeDisplay();
                        break;

                    case "3":
                        Console.Write(" Enter the amount you would like to scale the recipe by(0.5, 2, 3): ");
                        double scaleAmount = Convert.ToDouble(Console.ReadLine());
                        recipe.recipeScale(scaleAmount);
                        break;

                    case "4":

                        recipe.recipeReset();
                        break;

                    case "5":
                        recipe.recipeClear();
                        break;

                    case "6":
                        Console.WriteLine(" Closing Application");
                        return;

                    default:
                        Console.Write(" Invalid choice. Please enter a valid choice: ");
                        break;
                }
            }
        }
    }
}
